-- Update to use your new textures
entities.horror_melon = {
    name = "Horror Melon",
    textures = {
        feet = "feets.png",
        torso = "body.png",
        head = "head.png",
        arms = "Textures.png",
        legs = "Textures.png"
    },
    hp = 100,
    damage = 20,
    speed = 1.5,
    
    -- Rest of your entity definition...
}
